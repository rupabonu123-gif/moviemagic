from flask import Flask, render_template, request, redirect, url_for, session

app = Flask(__name__)
app.secret_key = 'secret-key'

# MOVIES list — update posters as needed!
MOVIES = [
    {
        'name': 'The Matrix',
        'poster': 'images/matrix.jpg'
    },
    {
        'name': 'Inception',
        'poster': 'images/inception.jpg'
    },
    {
        'name': 'Avengers: Endgame',
        'poster': 'images/avengers.jpg'
    },
    {
        'name': 'Interstellar',
        'poster': 'images/interstellar.jpg'
    }
]

@app.route('/')
def home():
    return render_template('home.html', movies=MOVIES)

@app.route('/booking', methods=['GET', 'POST'])
def booking():
    if request.method == 'POST':
        booking_data = {
            'movie': request.form.get('movie'),
            'location': request.form.get('location'),
            'date': request.form.get('date'),
            'time': request.form.get('time'),
            'seats': request.form.get('seats')
        }
        session['booking'] = booking_data
        return redirect(url_for('payment'))
    else:
        movie_name = request.args.get('movie')
        poster = request.args.get('poster')
        return render_template('booking.html', movie=movie_name, poster=poster)

@app.route('/payment', methods=['GET', 'POST'])
def payment():
    if request.method == 'POST':
        payment_data = {
            'payment_method': request.form.get('payment_method'),
            'account_number': request.form.get('account_number'),
            'cardholder': request.form.get('cardholder'),
            'expiry': request.form.get('expiry'),
            'cvv': request.form.get('cvv')
        }
        session['payment'] = payment_data
        return redirect(url_for('confirmation'))
    return render_template('payment.html')

@app.route('/confirmation')
def confirmation():
    booking = session.get('booking')
    payment = session.get('payment')
    return render_template('confirmation.html', booking=booking, payment=payment)

if __name__ == '__main__':
    app.run(debug=True)
